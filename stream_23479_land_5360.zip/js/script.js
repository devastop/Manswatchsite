$(document).ready(function() {




    $('.begin-tov-img').slick({
        infinite: true,
        autoplay: true,
        dots: false,
        arrows: false,
        fade: true,
        speed: 1000,
        slidesToShow: 1,
        slidesToScroll: 1
    }),
    $('.tov-gal').slick({
        infinite: true,
        autoplay: true,
        dots: false,
        arrows: true,
        fade: false,
        speed: 1000,
        slidesToShow: 1,
        slidesToScroll: 1,
        prevArrow: '<span data-role="none" class="slick-prev animate" aria-label="Previous" tabindex="0" role="button"></span>',
        nextArrow: '<span data-role="none" class="slick-next animate" aria-label="Next" tabindex="0" role="button"></span>'
    }),
    $('.rew-cont').slick({
        infinite: true,
        autoplay: false,
        dots: false,
        arrows: true,
        fade: false,
        speed: 300,
        slidesToShow: 3,
        prevArrow: '<span data-role="none" class="slick-prev animate" aria-label="Previous" tabindex="0" role="button"></span>',
        nextArrow: '<span data-role="none" class="slick-next animate" aria-label="Next" tabindex="0" role="button"></span>',
        responsive: [{
                breakpoint: 959,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1
                }
            },
            {
                breakpoint: 639,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
        ]
    });






});


/*scroll*/
$(function(){
        /* scroll */
    $("a[href^='#']").not('[data-fancybox]').click(function(){
        var _href = $(this).attr("href");
        $("html, body").animate({scrollTop: $(_href).offset().top+"px"});
        return false;
    });
});


/* timer */
function update() {
    var Now = new Date(), Finish = new Date();
    Finish.setHours( 23);
    Finish.setMinutes( 59);
    Finish.setSeconds( 59);
    if( Now.getHours() === 23  &&  Now.getMinutes() === 59  &&  Now.getSeconds === 59) {
        Finish.setDate( Finish.getDate() + 1);
    }
    var sec = Math.floor( ( Finish.getTime() - Now.getTime()) / 1000);
    var hrs = Math.floor( sec / 3600);
    sec -= hrs * 3600;
    var min = Math.floor( sec / 60);
    sec -= min * 60;
    $(".timer .hours").text( pad(hrs));
    $(".timer .minutes").text( pad(min));
    $(".timer .seconds").text( pad(sec));
    setTimeout( update, 200);
}
function pad(s) { return ('00'+s).substr(-2) }
update();
